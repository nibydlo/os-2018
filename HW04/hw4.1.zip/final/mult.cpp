extern "C" {
	int mult(int a, int b) {
		return a*b;
	}
}
