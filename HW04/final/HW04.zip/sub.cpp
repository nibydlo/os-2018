#include "dynamiclib1.h"

using namespace std;

int sub (int a, int b) {
	return a - b;
}
