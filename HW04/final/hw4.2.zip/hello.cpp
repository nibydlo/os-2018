#include <iostream>
#include "staticlib.h"

using namespace std;

void print_hello_static() {

	cout << "Hello static world!" << endl;
}
