#include "staticlib.h"

using namespace std;

int sum(int a, int b) {
	return a + b;
}
