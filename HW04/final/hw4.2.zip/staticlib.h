void print_hello_static();
int sum(int a, int b);
